KBL Dongne - Korea by Local's typeface
=======================================

Regular (400) and Bold (700). Latin only - there is no Hangul in this font.
Every letter is built from four shapes of Hunminjeongeum: the circle (ㅇ),
person (ㅣ), earth (ㅡ) and heaven (·). Story and rules:
https://koreabylocal.com/about#typeface

What's inside
- desktop-otf/  Design tools: Figma, Illustrator, Keynote
- office-ttf/   Word, PowerPoint and Windows (screen-hinted)
- web/          WOFF2 for websites
- kbl-dongne-specimen.svg  Full glyph specimen
- OFL.txt       The license (SIL Open Font License 1.1)

Install
- Mac: double-click each .otf file and click "Install Font".
- Windows: right-click each .ttf file and choose "Install".
- Design tools pick the font up once it is installed on your computer.

On a website
  @font-face { font-family: "KBL Dongne"; src: url(KBLDongne-Regular.woff2) format("woff2"); font-weight: 400; font-display: swap; }
  @font-face { font-family: "KBL Dongne"; src: url(KBLDongne-Bold.woff2) format("woff2"); font-weight: 700; font-display: swap; }
  body { font-family: "KBL Dongne", "Pretendard", "Apple SD Gothic Neo", "Noto Sans KR", system-ui, sans-serif; font-synthesis: none; }

Korean text falls through to the next font in the stack (Pretendard), so
always set the full stack, never "KBL Dongne" alone. There is no italic.

License
KBL Dongne is licensed under the SIL Open Font License, Version 1.1 (see
OFL.txt, or https://openfontlicense.org). You may use it free of charge in
personal and commercial work, embed it in websites, apps and documents, and
modify or redistribute it. The fonts may not be sold by themselves, and a
modified version must stay under the OFL and may not use the Reserved Font
Name "KBL Dongne". Documents you make with the font are not affected.

Copyright (c) 2026, Local Contents Lab (https://koreabylocal.com),
with Reserved Font Name "KBL Dongne".
